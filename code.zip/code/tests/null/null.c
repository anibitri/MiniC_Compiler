// MiniC program to test null file


